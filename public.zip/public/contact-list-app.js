angular.module("ContactListApp",[]);
console.log("Splited App initialized");

 